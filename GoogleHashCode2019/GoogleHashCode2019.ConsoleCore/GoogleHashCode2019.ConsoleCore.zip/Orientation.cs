﻿namespace GoogleHashCode2019.ConsoleNET
{
	public enum Orientation
	{
		Horizontal,
		Vertical
	}
}